// spectrum.c -- Spectra Explorer (derrickdemars.com/specexplore/)
// (c) 2026 Derrick DeMars. All rights reserved.
//
// Exhaustive search for the mixed Ramsey spectrum MRS(K_n; F, H): the set of all k such that some
// edge-coloring of the complete graph K_n with exactly k colors has no monochromatic copy of F and no
// rainbow copy of H. Rules, named as on the page:
//   A  Triangles             no monochromatic K3, no rainbow K3
//   B  Odd cycles / cycles   no monochromatic odd cycle (any length), no rainbow cycle (any length)
//   C  4-cycles              no monochromatic C4, no rainbow C4
//   D  Triangles + 5-cycles  no monochromatic K3 or C5, no rainbow K3   (the setting of Paper 4)
// Edges of K_n are colored one at a time in the order (0,1), (0,2), ..., (0,n-1), (1,2), ..., (n-2,n-1).
// Each edge takes an existing color or the next new one, so every coloring is visited once up to renaming
// the colors; a partial coloring is abandoned as soon as it completes a forbidden cycle.
//
// Usage:   ./spectrum RULE n [seconds]      e.g.  ./spectrum C 8
//   seconds = optional time limit; 0 or omitted means no limit (the search always runs to the end).
// Output:  one line of JSON: rule, n, complete (false only if a time limit stopped it), seconds (running
//   time, which varies between runs), nodes (partial colorings explored), cycles (forbidden cycles
//   tracked), spectrum (the numbers of colors that work), and witness: one example coloring per number of
//   colors, listed as one color index (0, 1, 2, ...) per edge in the order above.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAXN 9
#define MAXE 36
#define MAXC 200000

static int n, E, rule;
static int eu[MAXE], ev[MAXE], eid[MAXN][MAXN];
typedef struct { int len; int e[MAXN]; } Cyc;
static Cyc *cyc; static int ncyc;
static int *byLast[MAXE]; static int nbyLast[MAXE];
static int col[MAXE];
static int found[MAXE+2]; static int wit[MAXE+2][MAXE];
static long long nodes=0; static double tlimit; static clock_t t0; static int timedOut=0;

static void addCycle(int *vs, int len){
  if(ncyc>=MAXC){ fprintf(stderr,"too many cycles\n"); exit(1); }
  Cyc c; c.len=len; int mx=-1;
  for(int i=0;i<len;i++){ int a=vs[i], b=vs[(i+1)%len]; c.e[i]=eid[a][b]; if(c.e[i]>mx) mx=c.e[i]; }
  cyc[ncyc]=c; nbyLast[mx]++; ncyc++;
}
// enumerate each undirected cycle of length len once: smallest vertex first, second vertex < last vertex
static int path[MAXN], used[MAXN];
static void rec(int depth, int len){
  if(depth==len){ if(path[1]<path[len-1]) addCycle(path,len); return; }
  for(int v=path[0]+1; v<n; v++) if(!used[v]){ used[v]=1; path[depth]=v; rec(depth+1,len); used[v]=0; }
}
static void cycles(int len){
  for(int s=0;s<n;s++){ memset(used,0,sizeof used); used[s]=1; path[0]=s; rec(1,len); }
}
static int bad(Cyc *c){
  int L=c->len, a=col[c->e[0]], mono=1;
  for(int i=1;i<L;i++) if(col[c->e[i]]!=a){ mono=0; break; }
  if(mono){
    if(rule=='A'||rule=='C'||rule=='D') return 1;
    if(rule=='B' && (L%2==1)) return 1;
  }
  // rainbow check (rule D forbids rainbow triangles only)
  if(rule=='D' && L!=3) return 0;
  for(int i=0;i<L;i++) for(int j=i+1;j<L;j++) if(col[c->e[i]]==col[c->e[j]]) return 0;
  return 1;
}
static int allFound(int lo, int hi){ if(lo<1) lo=1; for(int k=lo;k<=hi;k++) if(!found[k]) return 0; return 1; }
static void dfs(int e, int usedc){
  nodes++;
  if(tlimit>0 && (nodes & 0xFFFFF)==0 && (double)(clock()-t0)/CLOCKS_PER_SEC > tlimit){ timedOut=1; }
  if(timedOut) return;
  if(e==E){ if(!found[usedc]){ found[usedc]=1; memcpy(wit[usedc],col,sizeof(int)*E); } return; }
  if(allFound(usedc, usedc+(E-e))) return;
  // try a new color first (reaches large k quickly), then existing colors
  for(int t=0;t<=usedc;t++){
    int c = (t==0) ? usedc : t-1;
    col[e]=c; int ok=1;
    for(int q=0;q<nbyLast[e];q++) if(bad(&cyc[byLast[e][q]])){ ok=0; break; }
    if(ok) dfs(e+1, c==usedc ? usedc+1 : usedc);
    if(timedOut) return;
  }
}
int main(int argc, char **argv){
  if(argc<3){ fprintf(stderr,"usage: spectrum RULE n [seconds]   (RULE = A, B, C, or D; 3 <= n <= 8)\n"); return 1; }
  rule=argv[1][0]; n=atoi(argv[2]); tlimit = argc>3 ? atof(argv[3]) : 0;
  E=0; for(int i=0;i<n;i++) for(int j=i+1;j<n;j++){ eu[E]=i; ev[E]=j; eid[i][j]=eid[j][i]=E; E++; }
  cyc=malloc(sizeof(Cyc)*MAXC);
  if(rule=='A') cycles(3);
  else if(rule=='C') cycles(4);
  else if(rule=='D'){ cycles(3); if(n>=5) cycles(5); }
  else for(int L=3;L<=n;L++) cycles(L);
  // bucket cycles by their last (highest-index) edge
  for(int e=0;e<E;e++){ byLast[e]=malloc(sizeof(int)*(nbyLast[e]+1)); nbyLast[e]=0; }
  for(int i=0;i<ncyc;i++){ int mx=-1; for(int k=0;k<cyc[i].len;k++) if(cyc[i].e[k]>mx) mx=cyc[i].e[k]; byLast[mx][nbyLast[mx]++]=i; }
  t0=clock(); dfs(0,0);
  double secs=(double)(clock()-t0)/CLOCKS_PER_SEC;
  printf("{\"rule\":\"%c\",\"n\":%d,\"complete\":%s,\"seconds\":%.2f,\"nodes\":%lld,\"cycles\":%d,\"spectrum\":[", rule,n, timedOut?"false":"true", secs, nodes, ncyc);
  int first=1; for(int k=1;k<=E;k++) if(found[k]){ printf("%s%d", first?"":",", k); first=0; }
  printf("],\"witness\":{");
  first=1; for(int k=1;k<=E;k++) if(found[k]){ printf("%s\"%d\":[", first?"":",", k); for(int e=0;e<E;e++) printf("%s%d", e?",":"", wit[k][e]); printf("]"); first=0; }
  printf("}}\n");
  return 0;
}
