# Spectra Explorer: code and results

© 2026 Derrick DeMars. All rights reserved.

These files produced and check the numbers on the Spectra Explorer page at
[derrickdemars.com/specexplore/](https://derrickdemars.com/specexplore/).

The **mixed Ramsey spectrum** MRS(K_n; F, H) is the set of all k such that some edge-coloring of the complete graph K_n with exactly k colors has no monochromatic copy of F and no rainbow copy of H. The page covers four rules on 3 to 8 vertices:

| Rule | Name on the page | Forbidden |
|---|---|---|
| A | Triangles | no monochromatic K3, no rainbow K3 |
| B | Odd cycles / cycles | no monochromatic odd cycle, no rainbow cycle (any length) |
| C | 4-cycles | no monochromatic C4, no rainbow C4 |
| D | Triangles + 5-cycles | no monochromatic K3 or C5, no rainbow K3 |

## What's here

| File | What it does |
|---|---|
| `spectrum.c` | Exhaustive search: for one rule and number of vertices, finds every number of colors that works, with one example coloring for each. |
| `verify.py` | Independent checker for the spectra and examples (written separately; shares no code with `spectrum.c`). |
| `verify_classes.py` | Independent checker for the extra colorings behind the page's **Next Coloring** button. |
| `run_all.sh` | One command: compiles `spectrum.c`, reruns every search, compares with the shipped results, and runs both checkers. |
| `results/spectrum/` | Output of all 24 searches (`out_RULE_n.json`). |
| `results/colorings/` | The extra colorings, one file per rule, number of vertices, and number of colors (`RULE_n_k.json`). |
| `results/page-data.json` | The data file the page itself uses (the spectra, examples, and colorings above, combined). |

## Requirements

* A C compiler (`cc`, `gcc`, or `clang`).
* Python 3, with [NumPy](https://numpy.org/) for `verify_classes.py`.

## Quick start

```sh
sh run_all.sh
```

This takes roughly 10 to 15 minutes (13 minutes on the computer used to build the page), most of it on the 4-cycles rule with 8 vertices. It should end by reporting that all 24 searches reproduce the shipped results and that both checkers found **0 problems**.

## Running the pieces yourself

```sh
cc -O2 -o spectrum spectrum.c
./spectrum C 6                 # rule C (4-cycles) on 6 vertices; prints one line of JSON
./spectrum B 8 60              # optional third argument: a time limit in seconds (0 or omitted = no limit)
python3 verify.py              # checks results/spectrum
python3 verify_classes.py      # checks results/colorings
```

## How the results are written

**Colorings.** The edges of K_n are always listed in the order (0,1), (0,2), …, (0,n−1), (1,2), …, (n−2,n−1). A coloring is a list with one color index (0, 1, 2, …) per edge, in that order. Colors are numbered in order of first appearance, so each coloring is listed once up to renaming the colors.

**`results/spectrum/out_RULE_n.json`** (from `spectrum.c`)

* `rule`, `n`: the rule letter and number of vertices
* `complete`: `true` if the search ran to the end (all shipped results did)
* `seconds`: running time; this is the only field that varies between runs
* `nodes`: partial colorings explored; `cycles`: forbidden cycles tracked
* `spectrum`: the numbers of colors that work
* `witness`: one example coloring for each number of colors in the spectrum

**`results/colorings/RULE_n_k.json`**

* `rule`, `n`, `k`: the rule, number of vertices, and number of colors
* `classes`: edge-colorings that obey the rule with exactly k colors, no two isomorphic (one can't be turned into another by relabeling the vertices and renaming the colors). If there are 10 or fewer, this is all of them; a list of 11 means at least 11 exist, and the search stopped there.
* `complete`, `stoppedAtMax`, `seconds`: bookkeeping from the search that found them

These colorings came from a separate search that is not part of this download. `verify_classes.py` checks them independently and needs only the colorings themselves.

**`results/page-data.json`**: for each rule and number of vertices, `s` is the spectrum, `w` gives the example coloring shown first for each number of colors, and `x` gives up to 9 more colorings for each number of colors, with `s` = `"all"` (these are all of them) or `"more"` (more exist).

## What the checks establish

* `verify.py`: every example coloring obeys its rule and uses exactly the stated number of colors. For 3 to 5 vertices, it also lists every coloring outright and recomputes the whole spectrum, which must match. For 6 to 8 vertices, the claim that no other numbers of colors work rests on the exhaustive search in `spectrum.c`, which you can rerun.
* `verify_classes.py`: every extra coloring obeys its rule with exactly the stated number of colors, no two in the same list are isomorphic (tested against every relabeling of the vertices), and for 3 to 5 vertices the lists are complete.

## The spectra

| Rule | 3 | 4 | 5 | 6 | 7 | 8 |
|---|---|---|---|---|---|---|
| Triangles (A) | {2} | {2, 3} | {2, 3, 4} | {3, 4, 5} | {3, 4, 5, 6} | {3, 4, 5, 6, 7} |
| Odd cycles / cycles (B) | {2} | {2, 3} | {3, 4} | {3, 4, 5} | {3, 4, 5, 6} | {3, 4, 5, 6, 7} |
| Triangles + 5-cycles (D) | {2} | {2, 3} | {3, 4} | {3, 4, 5} | {3, 4, 5, 6} | {3, 4, 5, 6, 7} |
| 4-cycles (C) | {1, 2, 3} | {2, 3, 4} | {2, 3, 4, 5} | {3, 4, 5, 6} | {3, 4, 5, 6, 7} | {3, 4, 5, 6, 7, 8} |

