#!/bin/sh
# run_all.sh -- Spectra Explorer (derrickdemars.com/specexplore/)
# (c) 2026 Derrick DeMars. All rights reserved.
#
# Reruns every spectrum search from scratch and checks everything:
#   1. compiles spectrum.c
#   2. reruns all 24 searches (4 rules x 3 to 8 vertices) into the folder "rerun", with no time limit
#   3. compares the new results with the shipped ones in results/spectrum (ignoring only the running time)
#   4. runs both independent checkers
# Needs a C compiler (cc or gcc) and Python 3 with NumPy. The whole run takes roughly 10 to 15 minutes
# (13 minutes on the computer used to build the page); most of it is the 4-cycles rule on 8 vertices.
set -e
cd "$(dirname "$0")"
CC=${CC:-cc}
echo "== Compiling spectrum.c"
$CC -O2 -o spectrum spectrum.c
mkdir -p rerun
echo "== Rerunning every search (no time limit)"
for R in A B C D; do
  for n in 3 4 5 6 7 8; do
    printf '   rule %s, %s vertices ... ' "$R" "$n"
    ./spectrum "$R" "$n" > "rerun/out_${R}_${n}.json"
    echo done
  done
done
echo "== Comparing with the shipped results"
python3 - <<'PY'
import json, glob, os
diff = 0
for f in sorted(glob.glob('results/spectrum/out_*_*.json')):
    a = json.load(open(f)); b = json.load(open(os.path.join('rerun', os.path.basename(f))))
    a.pop('seconds'); b.pop('seconds')          # running time differs between machines and runs
    if a != b: diff += 1; print('   DIFFERENT:', os.path.basename(f))
print('   all 24 searches reproduce the shipped results' if diff == 0 else f'   {diff} searches differ')
PY
echo "== Checking the rerun spectra and examples (verify.py)"
python3 verify.py rerun
echo "== Checking the extra colorings (verify_classes.py)"
python3 verify_classes.py
