# verify_classes.py -- Spectra Explorer (derrickdemars.com/specexplore/)
# (c) 2026 Derrick DeMars. All rights reserved.
#
# Independent checker for the extra edge-colorings behind the page's "Next Coloring" button. Those colorings
# were found by a separate search that is not part of this download; this checker needs only the colorings
# themselves (results/colorings). For every rule, number of vertices, and number of colors it confirms:
#   * each coloring obeys its rule and uses exactly the stated number of colors;
#   * no two are isomorphic (one cannot be turned into the other by relabeling the vertices and renaming
#     the colors), tested against every relabeling of the vertices;
#   * for 3 to 5 vertices, by listing every coloring outright, that the list is complete (or, when 11 are
#     listed, that at least 11 exist).
#
# Usage:  python3 verify_classes.py [folder]      (default folder: results/colorings)     Needs NumPy.
import json, glob, itertools, os, sys
import numpy as np
from verify import edges, ok, setpartitions

_PERMS = {}
def _perm_edge_index(n):
    """For every ordering of the n vertices, which original edge lands in each edge position."""
    if n in _PERMS: return _PERMS[n]
    E = edges(n); idx = {e: q for q, e in enumerate(E)}
    P = np.array(list(itertools.permutations(range(n))), dtype=np.int16)
    M = np.empty((len(P), len(E)), dtype=np.int16)
    for q, (i, j) in enumerate(E):
        a = P[:, i]; b = P[:, j]
        M[:, q] = [idx[(min(x, y), max(x, y))] for x, y in zip(a, b)]
    _PERMS[n] = M; return M

def canonical(n, col):
    """Smallest relabeled form over all n! vertex orders, colors renamed by first appearance.
    Two colorings are isomorphic exactly when their canonical forms are equal."""
    C = np.array(col, dtype=np.int16)[_perm_edge_index(n)]
    k = int(C.max()) + 1; rows = np.arange(C.shape[0])
    mp = np.full((C.shape[0], k), -1, dtype=np.int16); nxt = np.zeros(C.shape[0], dtype=np.int16); out = np.empty_like(C)
    for q in range(C.shape[1]):
        c = C[:, q]; cur = mp[rows, c]; new = cur < 0
        mp[rows[new], c[new]] = nxt[new]; nxt[new] += 1; out[:, q] = mp[rows, c]
    return tuple(out[np.lexsort(out.T[::-1])[0]])

def main(folder):
    files = sorted(glob.glob(os.path.join(folder, '*_*_*.json')))
    if not files: print('No colorings found in', folder); return 1
    bad = 0; total = 0
    for f in files:
        d = json.load(open(f)); r, n, k, cl = d['rule'], d['n'], d['k'], d['classes']
        forms = set()
        for col in cl:
            total += 1
            if not ok(r, n, col) or len(set(col)) != k: bad += 1; print('INVALID', r, n, k, col)
            forms.add(canonical(n, col))
        if len(forms) != len(cl): bad += 1; print('NOT ALL DIFFERENT', r, n, k)
        if n <= 5:
            everything = {canonical(n, col) for col in setpartitions(len(edges(n))) if len(set(col)) == k and ok(r, n, col)}
            if not (len(everything) == len(cl) or (len(cl) == 11 and len(everything) >= 11)):
                bad += 1; print('COUNT MISMATCH', r, n, k, len(everything), len(cl))
    print(f'{len(files)} combinations, {total} colorings checked | problems: {bad}')
    return 1 if bad else 0

if __name__ == '__main__':
    here = os.path.dirname(os.path.abspath(__file__))
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, 'results', 'colorings')))
