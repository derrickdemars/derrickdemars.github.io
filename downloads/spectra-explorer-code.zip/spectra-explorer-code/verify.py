# verify.py -- Spectra Explorer (derrickdemars.com/specexplore/)
# (c) 2026 Derrick DeMars. All rights reserved.
#
# Independent checker for the spectrum search. Written separately from spectrum.c and sharing no code with it.
#   * Every example coloring (witness) must obey its rule and use exactly the stated number of colors.
#   * For 3 to 5 vertices it also lists every coloring outright (one per way of renaming colors) and
#     recomputes the whole spectrum, which must match.
# For 6 to 8 vertices, that no other numbers of colors work rests on the exhaustive search in spectrum.c.
#
# Usage:  python3 verify.py [folder]      (default folder: results/spectrum)
import json, itertools, glob, os, sys

RULES = {  # which cycle lengths matter, as on the page
    'A': 'Triangles: no monochromatic K3, no rainbow K3',
    'B': 'Odd cycles / cycles: no monochromatic odd cycle, no rainbow cycle',
    'C': '4-cycles: no monochromatic C4, no rainbow C4',
    'D': 'Triangles + 5-cycles: no monochromatic K3 or C5, no rainbow K3',
}

def edges(n):
    """Edges of K_n in the order used everywhere: (0,1), (0,2), ..., (n-2,n-1)."""
    return [(i, j) for i in range(n) for j in range(i + 1, n)]

def all_cycles(n, L):
    """Every cycle of length L in K_n, once each."""
    seen = set(); out = []
    for vs in itertools.permutations(range(n), L):
        if vs[0] != min(vs): continue
        key = frozenset(frozenset((vs[i], vs[(i + 1) % L])) for i in range(L))
        if key in seen: continue
        seen.add(key); out.append(vs)
    return out

def ok(rule, n, col):
    """True if the coloring col (one color index per edge) obeys the rule."""
    idx = {e: k for k, e in enumerate(edges(n))}
    c = lambda a, b: col[idx[(min(a, b), max(a, b))]]
    lengths = [3] if rule == 'A' else [4] if rule == 'C' else [3, 5] if rule == 'D' else range(3, n + 1)
    for L in lengths:
        for vs in all_cycles(n, L):
            cs = [c(vs[i], vs[(i + 1) % L]) for i in range(L)]
            if len(set(cs)) == L and (rule != 'D' or L == 3): return False   # rainbow (rule D: triangles only)
            if len(set(cs)) == 1 and (rule != 'B' or L % 2 == 1): return False  # forbidden monochromatic cycle
    return True

def setpartitions(m):
    """Every coloring of m edges up to renaming colors: each edge uses an earlier color or the next new one."""
    def rec(k, mx, cur):
        if k == m:
            yield list(cur); return
        for c in range(mx + 2):
            cur.append(c); yield from rec(k + 1, max(mx, c), cur); cur.pop()
    yield from rec(0, -1, [])

def main(folder):
    files = sorted(glob.glob(os.path.join(folder, 'out_*_*.json')))
    if not files: print('No results found in', folder); return 1
    bad = 0
    for f in files:
        d = json.load(open(f)); r, n = d['rule'], d['n']
        if not d.get('complete', False): print(f, 'did not finish'); bad += 1
        for k, w in d['witness'].items():
            if not ok(r, n, w) or len(set(w)) != int(k): print('BAD EXAMPLE', r, n, k); bad += 1
        msg = f"rule {r}, {n} vertices: examples for {sorted(map(int, d['witness']))} colors all valid"
        if sorted(map(int, d['witness'])) != d['spectrum']: bad += 1; msg += ' | spectrum and examples disagree'
        if n <= 5:
            spec = sorted({len(set(col)) for col in setpartitions(len(edges(n))) if ok(r, n, col)})
            msg += f" | full listing gives spectrum {spec}: {'MATCH' if spec == d['spectrum'] else 'MISMATCH'}"
            if spec != d['spectrum']: bad += 1
        print(msg)
    print('problems:', bad)
    return 1 if bad else 0

if __name__ == '__main__':
    here = os.path.dirname(os.path.abspath(__file__))
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, 'results', 'spectrum')))
